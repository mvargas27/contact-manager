var contactApp = angular.module("contactApp", []);

contactApp.controller("ContactCtrl", function($scope){
	console.log("$scope.contact");

	$scope.contact = [
	{name:"Steve Wozniak", email:"woz@apple.com", location:"United States", phone:"718-886-5540"}
	{name:"Linus Torvalds", email:"linus@linux.com", location:"Finland", phone:"+358 9 568 042"}
	{name:"Bill Gates", email:"bill@microsoft.com", location:"United States", phone:"4841698514"}

	];

	$scope.saveContact = function(){
		console.log("Saving...");
		$scope.contact.push($scope.newContact);
		$scope.info = "New contact was succesfully added!";
		$scope.newContact ={};

	}
});
