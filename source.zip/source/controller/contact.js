var contactApp = angular.module('contactApp');

myApp.controller('ContactCtrl', ['$scope', '$http', '$location', '$routeParams', function($scope, $http, $location, $routeParams){
	console.log('ContactCtrl loaded...');

	$scope.getContact = function(){
		$http.get('/api/contact').success(function(response){
			$scope.contact = response;
		});
	}

	$scope.getContact = function(){
		var id = $routeParams.id;
		$http.get('/api/contact/'+id).success(function(response){
			$scope.contact = response;
		});
	}

	$scope.addContact = function(){
		console.log($scope.contact);
		$http.post('/api/contact/', $scope.contact).success(function(response){
			window.location.href='/contact';
		});
	}

	$scope.updateContact = function(){
		var id = $routeParams.id;
		$http.put('/api/contact/'+id, $scope.contact).success(function(response){
			window.location.href='/contact';
		});
	}

	$scope.removeContact = function(id){
		$http.delete('/api/contact/'+id).success(function(response){
			window.location.href='/contact';
		});
	}
}]);
