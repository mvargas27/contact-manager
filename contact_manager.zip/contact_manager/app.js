const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const mongoose = require('mongoose');

app.use(express.static(__dirname+'/packages installed'));
app.use(bodyParser.json());

Contact =require('./models/contact');

// Connect to Mongoose
mongoose.connect('mongodb://localhost/contactdb');
var db = mongoose.connection;

app.get('/', (req, res) => {
	res.send('welcome to contact app');
});

app.get('/api/contact', (req, res) => {   //get the input data
	Contact.getContact((err, contact) => {
		if(err){
			throw err;
		}
		res.json(contact);
	});
});

app.post('/api/contact', (req, res) => {      //add contact
	var contact = req.body;
	Contact.addContact(genre, (err, genre) => {
		if(err){
			throw err;
		}
		res.json(contact);
	});
});

app.put('/api/contact/:_id', (req, res) => {
	var id = req.params._id;
	var contact = req.body;
	Contact.updateContact(id, contact, {}, (err, contact) => {
		if(err){
			throw err;
		}
		res.json(contact);
	});
});

app.delete('/api/contact/:_id', (req, res) => {
	var id = req.params._id;
	Contact.removeContact(id, (err, contact) => {
		if(err){
			throw err;
		}
		res.json(contact);
	});
});



app.listen(3000);
console.log('Running on port 3000...');
