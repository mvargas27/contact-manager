const mongoose = require('mongoose');

// Contact Schema
const contactSchema = mongoose.Schema({
	name:{
		type: String,
		required: true
	},
	email:{
		type: String,
		required: true
	},
	location:{
		type: String
	},
	phone:{
		type: String,
		required: true

	}
});

const Contact = module.exports = mongoose.model('Contact', contactSchema);

// Get contacts
module.exports.getContact = (callback, limit) => {
	Contact.find(callback).limit(limit);
}

// Get contact
module.exports.getContactById = (id, callback) => {
	Contact.findById(id, callback);
}

// Add Contact
module.exports.addContact = (contact, callback) => {
	Contact.create(contact, callback);
}

// Update Contacts
module.exports.updateBook = (id, book, options, callback) => {
	var query = {_id: id};
	var update = {
		name: contact.name,
		email: contact.email,
		location: contact.location,
		phone: contact.phone

	}
	Contact.findOneAndUpdate(query, update, options, callback);
}

// Delete Contacts
module.exports.removeBook = (id, callback) => {
	var query = {_id: id};
	Contact.remove(query, callback);
}
