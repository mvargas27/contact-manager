var contactApp = angular.module('contactApp',['ngRoute']);

contactApp.config(function($routeProvider){
	$routeProvider.when('/', {
		controller:'ContactCtrl',
		templateUrl: 'index.html'
	})
	.when('/contact', {
		controller:'ContactCtrl',
		templateUrl: 'views/contact.html'
	})

	.when('/contact/add',{
		controller:'ContactCtrl',
		templateUrl: 'views/add-contact.html'
	})
	.otherwise({
		redirectTo: '/'
	});
});
